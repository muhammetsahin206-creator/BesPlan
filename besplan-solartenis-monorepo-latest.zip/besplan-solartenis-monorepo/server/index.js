console.log('BesPlan SolarTenis server skeleton running');

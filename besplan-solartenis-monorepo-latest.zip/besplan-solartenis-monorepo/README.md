# BesPlan & SolarTenis – Monorepo Skeleton (SDK 54 Uyumlu)

Bu paket, BesPlan ve SolarTenis için mobil (Expo) + server (Node/Express + Prisma) iskeletini içerir.

## Klasörler
- mobile/ : Expo (React Native)
- server/ : Express + Prisma

## Çalıştırma
### Server
cd server
npm install
npm run dev

### Mobile
cd mobile
npm install
npx expo start
